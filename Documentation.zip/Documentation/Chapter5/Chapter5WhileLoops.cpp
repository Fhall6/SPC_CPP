//darlene westberg
//August 30, 2018 �
//Chapter 5 while loops
#include <iostream>
using namespace std;

int main()
{
	/*
	while( test)
	{
		statement(s);
	}
	while loop normally test something before the loop executes and the loop continues as long as the test is true
	*/
	int a, b;
	for (a = 0; a < 11; a++)
		cout << a << endl;
	b = 0;
	//b = 11; while loop may never execute if condition is false
	while (b < 11)
	{
		cout << b << endl;
		b++;
	}
	//start at 11 and execute in reverse to 0
	while (b > -1)
	{
		cout << b << endl;
		b--;
	}
	/*Standard Data Processing Loop
	while loop that gets the first item of data before entering the loop
	data is tested
	processing occurs
	get the next item of data is read and tested*/
	a = 0;
	cout << "Enter a value and I will tell you the remainder of dividing by 3" << endl;
	cout << "Zero (0) to Quit" << endl;
	cin >> a;
	while (a) //or a!=0
	{
		cout << a % 3 << endl;
		cout << "Enter a value and I will tell you the remainder of dividing by 3" << endl;
		cout << "Zero (0) to Quit" << endl;
		cin >> a;
	}
	/*
	do...while is a post loop test so it will always execute at least once
	test is at the end...ends with a semicolon (;)*/
	do
	{
		cout << "Enter a number, 0 to quit" << endl;
		cin >> a;
		if (a % 2 == 0)
			cout << a << " is an even number" << endl;
		else
			cout << a << " is an odd number" << endl;
	} while (a != 0);
	char letter = 'A';
	while (letter != 'z' && letter != 'Z')
	{
		cout << "Enter a letter of the alphabet and I will give you its ASCII value\n";
		cout << "Enter z or Z to quit" << endl;
		cin >> letter;
		cout << "ASCII value for " << letter << " is " << (int)letter << endl;
	}
	system("pause");
	return 0;
}