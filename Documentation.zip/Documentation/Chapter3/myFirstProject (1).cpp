//darlene westberg.
//October 16, 2019 �
//My First Program
#include <iostream>
#include<iomanip>

using namespace std;

int main()
{
	int a, b, c;//don't ever name variables a, b, and c
	float d;
	char name[31] = "darlene westberg";
	double x = 1.23456789;
	double y = 12345.6789;
	cout << "Hello World!" << endl;//output statement
	cout << "Please enter a whole number " << '\n';
	cin >> a;
	cout << "Please enter another whole number " << '\n';
	cin >> b;
	d = (float)a / b;
	cout << "The result of dividing your first number by your second number is " << d << endl;
	cout << setprecision(8) << x << endl;
	cout << "the value in x is " << x << endl;
	cout << "the value in y is " << y << endl;
	cout << setw(12) << d << endl;
	cout << d << endl;
	cout << name << endl;
	cout << "Please enter another name " << endl;
	cin.ignore();
	cin.getline(name, 31);
	cout << name;
	cout << "\a\a\a\a\a" << endl;
	cout << sizeof(name) << endl;
	cout << sizeof(d) << endl;
	cout << sizeof(x) << endl;


	system("pause");
	return 0;
}
